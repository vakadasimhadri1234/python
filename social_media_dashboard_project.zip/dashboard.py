import streamlit as st
import pandas as pd

data = pd.read_csv('data.csv')

st.title("Social Media Dashboard")

st.write("Social Media Data")
st.dataframe(data)

st.bar_chart(data.set_index('platform')['likes'])

st.line_chart(data.set_index('platform')['comments'])
