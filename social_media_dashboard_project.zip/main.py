import pandas as pd
import matplotlib.pyplot as plt

# Load data
data = pd.read_csv('data.csv')

# Display data
print("Social Media Data")
print(data)

# Analytics
print("\nTotal Likes:", data['likes'].sum())
print("Total Comments:", data['comments'].sum())
print("Total Shares:", data['shares'].sum())

# Engagement
data['engagement'] = data['likes'] + data['comments'] + data['shares']
print("\nEngagement Data")
print(data[['platform', 'engagement']])

# Bar Chart
plt.bar(data['platform'], data['likes'])
plt.title("Likes per Platform")
plt.xlabel("Platform")
plt.ylabel("Likes")
plt.show()

# Pie Chart
plt.pie(data['shares'], labels=data['platform'], autopct='%1.1f%%')
plt.title("Share Distribution")
plt.show()
