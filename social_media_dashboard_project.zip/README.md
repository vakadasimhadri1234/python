# Social Media Dashboard

A beginner-friendly Python project for analyzing social media data.

## Features
- Likes analysis
- Comments tracking
- Share visualization
- Bar charts
- Pie charts
- Engagement calculation

## Technologies Used
- Python
- Pandas
- Matplotlib
- Streamlit (Optional)

## Project Structure
social_dashboard/
│
├── main.py
├── dashboard.py
├── data.csv
└── README.md

## How to Run

1. Install libraries:

pip install pandas matplotlib streamlit

2. Run Python file:

python main.py

3. Run Streamlit dashboard:

streamlit run dashboard.py

## Author
Simha
